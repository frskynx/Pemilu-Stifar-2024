<!-- <form action="<?=site_url('welcome/createAction');?>" method="POST">
    <input type="text" name="username">
    <input type="text" name="password">
    <button type="submit">buat</button>
</form> -->